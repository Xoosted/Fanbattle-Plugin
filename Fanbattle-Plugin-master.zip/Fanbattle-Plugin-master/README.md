**Fan Battle Plugin Information**

**How to use**
1. Execute /fb start to start the event
2. The server will announce "Fan Battle is now active! use /fb join"
3. Have fun!

**Commands**
1. /fb help ("Shows commands that you have access")
2. /fb info ("Shows credits for this plugin development")
3. /fb join ("Allows you to join an active Fan Battle")
4. /fb leave ("Allows you to leave the Fan Battle that you've joined")
